#pragma once
#include <stdlib.h>
#include <string>
#include <mutex>
#include <sys/time.h>
#include <stdarg.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <dlfcn.h>
#include <sys/wait.h>
#include <ucontext.h>
#include <signal.h>
#include <execinfo.h>
#include "syncu.h"
#include "serial.h"

#define         UART_BAUD_RATE          (115200)
#define         UART_DATA_BIT           (8)
#define         UART_STOP_BIT           (1)
#define         UART_PARITY             'N'
#define         UART_FLOW_CTL            0
#define         CPLD_TIME_OUT           (1000)  //ms

class CCpldBase
{
public:
	CCpldBase();
	virtual ~CCpldBase();
	virtual int Init(int mode, const char* devname) = 0;
	virtual int ReadVersion(char* buf,int len) = 0;
	virtual int Release() = 0;
	virtual int DisableTrig() = 0;
	virtual int EnableTrig() = 0;
	virtual int SetTimeMode(int chan, int fps, double width,int offset) = 0;
	virtual int SetManualMode(int chan, double width, int offset) = 0;
	virtual int DoTrig(int chan, double width, int offset) = 0;
	virtual int ReadTimeStamp(TSyncuStamp* tv) = 0;
	virtual int Readl(unsigned int dwReg,unsigned int *dwVal) ;
	virtual int Writel(unsigned int dwReg,unsigned int dwVal);
	virtual int SetInputSerialParam(int channel,const char* level ,int baudRate)=0;
	virtual int SetOutputSerialParam(int channel,const char* level ,int baudRate)=0;
	int	transAtoi(const char* str, int len);
	int	transXtoi(const char* str, int len);
protected:
	int				                                        m_nGpsMode;
	std::string		                                 m_strDevName;
	std::mutex		       m_mutex;
	CSerial*		                                  m_serial;
};
