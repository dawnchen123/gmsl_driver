﻿#ifndef _H_SERIAL_H
#define _H_SERIAL_H

#if defined(_WIN64) || defined(_WIN32)
#include <stdio.h>
#include <windows.h> 
#include <tchar.h> 
#define INPUT_BUFFER_SIZE 1024
#define OUTPUT_BUFFER_SIZE 1024

#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <termios.h>
#include <sys/time.h>
#endif
class CSerial
{
public:
	CSerial();
	~CSerial();

	int  Uart_open(const char* dev_name, int a_baud, int a_databits, int a_stopbits, char a_parity, int a_flowctl);
	void Uart_close();
	int  Uart_send(const char* send_buf, size_t send_len);
	int  Uart_read(char* read_buf, size_t read_len);
	int  Uart_readn(char* read_buf, size_t read_len, int time_out_ms);
	bool Is_open() { return open_status; }
	int  Uart_read_line(char* read_buf, size_t read_len, int time_out_ms);

private:
#if defined(_WIN64) || defined(_WIN32)
	HANDLE serialfd;
#else
	int serialfd = 0;
#endif
	int baudrate = 115200;
	int databits = 8;
	int stopbits = 1;
	char parity = 'N';
	int flow_ctl = 0;

	bool open_status = false;
};
#endif