 #pragma once

 #include <new>
#include <mutex>
#include <errno.h>
#include <time.h>
#include "cpld_base.h"
#include "serial.h"

#pragma pack(1)
typedef struct
{
	unsigned int     dwHead;		//CPLD_MSG_HEAD_V1
	unsigned char    bySeq;
	unsigned char    byAction;
	unsigned short   wType;
	unsigned short   wSize;
}TCpldV1MsgHead;


typedef struct
{
	unsigned char  byCheck;
	unsigned int   dwTail;
}TCpldV1MsgTail;

typedef struct 
{
	TCpldV1MsgHead	 stuHead;
	TCpldV1MsgTail	 stuTail;
}TCpldV1TimeStampReq;

typedef struct
{
	TCpldV1MsgHead	 stuHead;
	unsigned char    szTime[21];
	TCpldV1MsgTail	 stuTail;
}TCpldV1TimeStampRes;

typedef struct 
{
	TCpldV1MsgHead	 stuHead;
	unsigned char    szTime[21];
	TCpldV1MsgTail	 stuTail;
}TCpldV1SetInitTimeReq;


typedef struct
{
	TCpldV1MsgHead	stuHead;
	unsigned char   byErrCode;
	TCpldV1MsgTail	stuTail;
}TCpldV1ErrorMsg;

#pragma pop()

class CCpldV1 : public CCpldBase
{
	public:
		CCpldV1();
		virtual	~CCpldV1();
		virtual	int Init(int gpstype, const char* devname);
		virtual int ReadVersion(char* buf,int len);
		virtual	int Release();
		virtual	int DisableTrig();
		virtual	int EnableTrig();
		virtual	int SetTimeMode(int chan, int fps, double width, int offset);
		virtual	int SetManualMode(int chan, double width, int offset);
		virtual	int DoTrig(int chan, double width,int offset);
		virtual	int ReadTimeStamp(TSyncuStamp* tv);
		virtual int Readl(unsigned int dwReg,unsigned int *dwVal) ;
		virtual int Writel(unsigned int dwReg,unsigned int dwVal);
		virtual int SetInputSerialParam(int channel,const char* level ,int baudRate);
		virtual int SetOutputSerialParam(int channel,const char* level ,int baudRate);
	private:
		void showVersion();
		int  writel(unsigned int dwReg,unsigned dwVal);
		int  readl(unsigned int dwReg,unsigned int &dwVal);
		int	 requestCpld(void * pSrc, int nSrcLen, void* pDst, int nDstLen, int& nRealLen);
		int  setInitTime();
		void resetSerial();
		unsigned char calCheck(unsigned char* szBuf, int len);
		
		int cpld_atoi(const char *str,int len);
		int cpld_xtoi(const char *str,int len);
		void  cpld_nor(int len,unsigned char &check,char *szBuf);
		void reset_serial();
		int check_send_cpld_msg(char* szBuf,char* out,int send_len);
		int check_send_set(char* szBuf,int send_len);
		int cpld_read(unsigned int reg,char *out);
		int cpld_read_time(char *out);
		int cpld_writel(unsigned int reg, unsigned int value);
	private:
		bool m_bCompensation;
		bool m_bSetInput;
};
