#pragma once
#include <new>
#include <mutex>
#include <errno.h>
#include <time.h>
#include "serial.h"
#include "cpld_base.h"


class CCpldV0 : public CCpldBase
{
public:
	CCpldV0();
	virtual ~CCpldV0();
	virtual int Init(int gpstype,const char* devname);
	virtual int ReadVersion(char* buf,int len);
	virtual int Release();
	virtual int DisableTrig();
	virtual int EnableTrig();
	virtual int SetTimeMode(int chan, int fps, double width, int offset);
	virtual int SetManualMode(int chan, double width, int offset);
	virtual int DoTrig(int chan, double width,int offset);
	virtual int ReadTimeStamp(TSyncuStamp* tv);
	virtual int SetInputSerialParam(int channel,const char* level ,int baudRate);
	virtual int SetOutputSerialParam(int channel,const char* level ,int baudRate);
	
private:
	int cpld_read(unsigned int reg, char* out, int outlen);
	unsigned int cpld_read(unsigned int reg);
	int cpld_writel(unsigned int reg, unsigned int value);
	int cpld_writew(unsigned int reg, unsigned short value);
	int cpld_writeb(unsigned int reg, unsigned char value);
};
