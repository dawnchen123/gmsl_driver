﻿#include "serial.h"
#define INTERRUPED_SYSTEM_CALL 4

CSerial::CSerial()
{
}

CSerial::~CSerial()
{
}

int CSerial::Uart_open(const char* dev_name, int a_baud, int a_databits, int a_stopbits, char a_parity, int a_flowctl)
{
#if defined(_WIN64) || defined(_WIN32)
	serialfd = CreateFile((LPCSTR)dev_name, GENERIC_READ | GENERIC_WRITE,
		0, NULL, OPEN_EXISTING, 0, NULL);
	if (INVALID_HANDLE_VALUE == serialfd) {
		return -1;
	}

	DCB dcb;
	if (!GetCommState(serialfd, &dcb))
	{
		return -1;
	}
#ifdef SERIAL_HIGH_SPEED_MODE_X8
	dcb.BaudRate = a_baud / 8;
#else
	dcb.BaudRate = a_baud;
#endif
	dcb.ByteSize = a_databits;
	//dcb.StopBits = a_stopbits;
	switch (a_stopbits)
	{
	case 1:
		dcb.StopBits = 0;
	case 2:
		dcb.StopBits = 2;
	}
	
	switch (a_parity)
	{
	case 'o':
	case 'O':       //odd check	
		dcb.Parity = 1;
		break;
	case 'e':
	case 'E':       //even check
		dcb.Parity = 2;
		break;
	case 'n':
	case 'N':       //no check
		dcb.Parity = 0;
		break;
	default:
		fprintf(stderr, "unsupported parity\n");
		return -1;
	}

	if (!SetCommState(serialfd, &dcb))
	{
		return -1;
	}

	SetupComm(serialfd, INPUT_BUFFER_SIZE, OUTPUT_BUFFER_SIZE);     //设置缓冲区
	PurgeComm(serialfd, PURGE_RXCLEAR | PURGE_TXCLEAR | PURGE_RXABORT | PURGE_TXABORT);     //清空缓冲区


	COMMTIMEOUTS ts;
	if(GetCommTimeouts(serialfd,&ts) == TRUE)
	{
		//读间隔超时接收时,默认值时4，两字符间最大的时延,单位ms
		ts.ReadIntervalTimeout = 4;
		//指定以毫秒为单位的常数。用于计算读操作时的超时总数。对于每次读操作，ReadTotalTimeoutMultiplier与所要读的字节数相乘后与该值相加
		ts.ReadTotalTimeoutMultiplier = 1;
		ts.WriteTotalTimeoutConstant = 0;
		SetCommTimeouts(serialfd,&ts);
	}
	
#else        
	serialfd = open(dev_name, O_RDWR | O_NOCTTY | O_NDELAY);
	if (serialfd < 0) 
	{
		return -1;
	}

	if (fcntl(serialfd, F_SETFL, 0) < 0) // block status
	{
		return -1;
	}

	baudrate = a_baud;
	databits = a_databits;
	stopbits = a_stopbits;
	parity = a_parity;
	flow_ctl = a_flowctl;
	struct termios options = { 0 };

	if (tcgetattr(serialfd, &options) != 0)
	{
		return -1;
	}

	options.c_cflag |= CLOCAL | CREAD; // ctrl mode , program can't occupy uart but read data
	options.c_iflag &= ~(IXON | IXOFF | IXANY | ICRNL | IGNCR); //for linux       change: ! to ~

	switch (baudrate) {
	case 2400:
		cfsetispeed(&options, B2400);
		cfsetospeed(&options, B2400);
		break;
	case 4800:
		cfsetispeed(&options, B4800);
		cfsetospeed(&options, B4800);
		break;
	case 9600:
		cfsetispeed(&options, B9600);
		cfsetospeed(&options, B9600);
		break;
	case 115200:
		cfsetispeed(&options, B115200);
		cfsetospeed(&options, B115200);
		break;
	case 230400:
		cfsetispeed(&options, B230400);
		cfsetospeed(&options, B230400);
		break;
	case 460800:
		cfsetispeed(&options, B460800);
		cfsetospeed(&options, B460800);
		break;
	default:
		cfsetispeed(&options, B115200);
		cfsetospeed(&options, B115200);
		break;
	}

	options.c_cflag &= ~CSIZE;      //reset databits
	switch (databits) {
	case 7:
		options.c_cflag |= CS7;         //7 bits
		break;
	case 8:
		options.c_cflag |= CS8;         //8 bits
		break;
	}

	switch (parity) {
	case 'o':
	case 'O':       //odd check
		options.c_cflag |= (PARENB | PARODD);
		options.c_iflag |= (INPCK | ISTRIP);            //why ISTRIP?
		break;

	case 'e':
	case 'E':       //even check
		options.c_iflag |= (INPCK | ISTRIP);
		options.c_cflag |= PARENB;
		options.c_cflag &= ~PARODD;
		break;

	case 'n':
	case 'N':       //no check
		options.c_cflag &= ~PARENB;
		options.c_iflag &= ~INPCK;
		break;

	default:
		fprintf(stderr, "unsupported parity\n");
		return -1;
	}

	switch (stopbits)
	{
	case 1:
		options.c_cflag &= ~CSTOPB;
		break;
	case 2:
		options.c_cflag |= CSTOPB;
		break;
	default:
		fprintf(stderr, "unsupported stop bits\n");
		return -1;
	}

	switch (flow_ctl)
	{
	case 0:         //no flow ctl
		options.c_cflag &= ~CRTSCTS;
		break;
	case 1:         //hardware flow ctl
		options.c_cflag |= CRTSCTS;
		break;
	case 2:         //software flow ctl
		options.c_cflag |= IXON | IXOFF | IXANY;
		break;
	}

	options.c_cc[VTIME] = 0;
	options.c_cc[VMIN] = 1;

	options.c_lflag &= ~(ECHO | ECHONL | ICANON | IEXTEN | ISIG);      //for linux
	options.c_oflag &= ~OPOST;      //no output processing 

	tcflush(serialfd, TCIOFLUSH);
	if ((tcsetattr(serialfd, TCSANOW, &options)) != 0) {
		return -1;
	}
#endif
	open_status = true;
	return 0;
}

void CSerial::Uart_close()
{
	if (open_status == true)
#if defined(_WIN64) || defined(_WIN32)   
		CloseHandle(serialfd);
#else
		close(serialfd);
#endif
	open_status = false;
}

int CSerial::Uart_send(const char* send_buf, size_t send_len)
{
#if defined(_WIN64) || defined(_WIN32)
	unsigned int write_num = 0;
	if (!WriteFile(serialfd, send_buf, (DWORD)send_len, (LPDWORD)&write_num, NULL)) {
		return -1;
	}
	return write_num;
#else
	return write(serialfd, send_buf, send_len);
#endif
}

int CSerial::Uart_read(char* read_buf, size_t read_len)
{
#if defined(_WIN64) || defined(_WIN32)
	unsigned int read_num = 0;
	if (!ReadFile(serialfd, read_buf, (DWORD)read_len, (LPDWORD)&read_num, NULL))
	{
		return -1;
	}
	return read_num;
#else
	return read(serialfd, read_buf, read_len);
#endif
}

int CSerial::Uart_read_line(char* read_buf, size_t read_len, int time_out_ms)
{
	if (open_status == false)
	{
		printf("%s:uart is not opened\n", __func__);
		return -1;
	}

#if defined(_WIN64) || defined(_WIN32)
	int left = (int)read_len;
	int reads = 0;
	int read_num = 0;
	unsigned int start_time = GetTickCount();
	unsigned int cost = 0;
	while (left > 0)
	{
		if ((int)cost > time_out_ms)
		{
			printf("%s:read timeout\n", __func__);
			return -1;
		}
		if (!ReadFile(serialfd, read_buf + reads, left - reads, (LPDWORD)&read_num, NULL))
		{
			printf("%s:read failed\n", __func__);
			return -1;
		}
		reads += read_num;
		left -= read_num;
		if (read_buf[reads - 1] == '\n')
		{
			return reads;
		}
		cost = GetTickCount() - start_time;
	}
	return -1;

#else
	int	left = read_len;
	struct timeval 	select_timeout = { time_out_ms / 1000,(time_out_ms % 1000) * 1000 };
	fd_set rset;
	int  retval = 0;
	int reads = 0;

	if (serialfd < 0)
	{
		return -1;
	}

	while (left > 0)
	{
		FD_ZERO(&rset);
		FD_SET(serialfd, &rset);
		if (select(serialfd + 1, &rset, NULL, NULL, &select_timeout) <= 0)
		{
			printf("%s:select failed,errno=%u\n", __func__, errno);
			return -1;
		}

		if ((retval = read(serialfd, read_buf + reads, left)) < 0)
		{
			if (errno == EINTR)
			{
				retval = 0;
			}
			else
			{
				return -1;
			}
		}
		else if (retval == 0)
		{
			break;
		}
		//printf("====%s",read_buf);
		reads += retval;
		left -= retval;
		if (read_buf[reads - 1] == '\n')
		{
			return reads;
		}
	}
	return-1;
#endif
}

int CSerial::Uart_readn(char* read_buf, size_t read_len, int time_out_ms)
{
	if (open_status == false)
	{
		printf("%s:uart is not opened\n", __func__);
		return -1;
	}

#if defined(_WIN64) || defined(_WIN32)
	int left = (int)read_len;
	int reads = 0;
	int read_num = 0;
	unsigned int start_time = GetTickCount();
	unsigned int cost = 0;
	while (left > 0)
	{
		if ((int)cost > time_out_ms)
		{
			printf("%s:read timeout\n", __func__);
			return -1;
		}
		if (!ReadFile(serialfd, read_buf + reads, left - reads, (LPDWORD)&read_num, NULL))
		{
			printf("%s:read failed\n", __func__);
			return -1;
		}
		reads += read_num;
		left -= read_num;
		if (reads == read_len)
		{
			return reads;
		}
		cost = GetTickCount() - start_time;
	}
	return reads;

#else
	int	left = read_len;
	struct timeval 	select_timeout = { time_out_ms / 1000,(time_out_ms % 1000) * 1000 };
	fd_set rset;
	int  retval = 0;
	int reads = 0;

	if (serialfd < 0)
	{
		return -1;
	}

	while (left > 0)
	{
		FD_ZERO(&rset);
		FD_SET(serialfd, &rset);
		if (select(serialfd + 1, &rset, NULL, NULL, &select_timeout) <= 0)
		{
			printf("%s:select failed,errno=%u\n", __func__, errno);
			if(errno == INTERRUPED_SYSTEM_CALL)
			{
				continue;
			}
			else
			{
				break;
			}	
		}

		if ((retval = read(serialfd, read_buf + reads, left)) < 0)
		{
			if (errno == EINTR)
			{
				retval = 0;
			}
			else
			{
				printf("%s:read failed,errno=%u\n", __func__, errno);
				return -1;
			}
		}
		else if (retval == 0)
		{
			break;
		}
		//printf("====%s",read_buf);
		reads += retval;
		left -= retval;
	}
	return reads;
#endif
}
