#include "cpld_v1.h"
#define CPLD_MSG_HEAD_V1	(0x24747a24)
#define CPLD_MSG_TAIL_V1	(0x23656423)

CCpldV1::CCpldV1()
{
	m_bCompensation = false;
	m_bSetInput = false;
}

CCpldV1::~CCpldV1()
{

}

 int CCpldV1::Init(int mode, const char* devname)
{
    int retval  = -1;
    do
    {
		if (m_serial)
		{
			printf("alread inited\n");
			break;
		}
		m_serial = new CSerial;
		if (m_serial == NULL)
		{
			printf("new Serial failed,errno %d\n", errno);
			break;
		}
		if (m_serial->Uart_open(devname, UART_BAUD_RATE, UART_DATA_BIT, UART_STOP_BIT, UART_PARITY, UART_FLOW_CTL) < 0)
		{
			printf("uart_open %s failed,errno %d\n", devname, errno);
			break;
		}



		m_nGpsMode = mode;
		m_strDevName = devname;
		switch(m_nGpsMode)
		{
			case 0:
			{
				writel(0x00020004,0);
				writel(0x0002002c,0);
				m_bSetInput = false;
				break;
			}

			case 1:
			{
				writel(0x00020004,1);
				writel(0x0002002c,0);
				m_bSetInput = true;
				break;
			}	
			case 2:
			{
				writel(0x0002002c,1);
				setInitTime();
				break;
			}
			default:
				break;
		}
		//读取版本和序列号
		showVersion();
		retval  = 0;

    } while (0);
        
    if(retval != 0)
    {
		if(m_serial)
		{
			delete m_serial;
			m_serial = NULL;
		}	
    }
    return retval;
}

 int CCpldV1::Release()
{
	 if (m_serial)
	 {
		 delete m_serial;
		 m_serial = NULL;
	 }
	 return 0;
}

int	 CCpldV1::EnableTrig()
{ 	
    if(m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
    }
	std::lock_guard<std::mutex> lock(m_mutex);
	unsigned int dwReg = 0x00030000;
	unsigned int dwVal = 4095;
	return writel(dwReg, dwVal);
}

int	 CCpldV1::DisableTrig()
{	
	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}
	std::lock_guard<std::mutex> lock(m_mutex);
	unsigned int dwReg = 0x00030000;
	unsigned int dwVal = 0x00000000;
	return writel(dwReg, dwVal);
}

int	 CCpldV1::SetTimeMode(int chan, int fps, double width, int offset)
 {	
    if(m_serial == NULL)
    {
		printf("m_serial is NULL\n");
		return -1;
    }
    if(chan >= MAX_TRIG_CHAN_NUM)
    {
		printf("chan over max_trig_chan_num\n");
		return -1;
    }

	printf("chan[%d] fps[%d] widht[%.3f],offset[%d]\n",chan,fps,width,offset);

	std::lock_guard<std::mutex> lock(m_mutex);
	
	
	unsigned int reg[] = { 0x3000C,0x30018,0x30024,0x30030,0x3003c,0x30048,0x30054,0x30060 ,0x3006C,0x30078,0x30084,0x30090};//寄存器flag
    unsigned int dstfreq =  1e8/fps;
	unsigned int dstwidth =  1e8/1e6*width;
	unsigned int dstOffset =  offset ? 100 * offset : 0;

	writel(reg[chan],dstfreq);		//fps
	writel(reg[chan]+4,dstwidth);	//脉宽
	writel(reg[chan] + 8, dstOffset);//偏移
    return 0;
 }

int CCpldV1::SetManualMode(int chan, double width, int offset)
{	
	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}
	if (chan >= MAX_TRIG_CHAN_NUM)
	{
		printf("chan over max_trig_chan_num\n");
		return -1;
	}

	std::lock_guard<std::mutex> lock(m_mutex);
	unsigned int dstwidth = 1e8 * (width / 1e9);
	unsigned int dstOffset = offset ? 100 * offset : 0;
	unsigned int reg[] = { 0x3000C,0x30018,0x30024,0x30030,0x3003c,0x30048,0x30054,0x30060,0x3006C,0x30078,0x30084,0x30090};//寄存器flag

	writel(0x00030008, 0);				//距离触发
	writel(reg[chan] + 4, dstwidth);	//脉宽
	writel(reg[chan] + 8, dstOffset);		//偏移
	return 0;
}

int CCpldV1::DoTrig(int chan,double width,int offset)
{
	if(m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}

	std::lock_guard<std::mutex> lock(m_mutex);
	writel(0x00030008, 0);				//距离触发

	unsigned int dstwidth = 1e8 * (width / 1e9);
	unsigned int dstOffset = offset ? 100* offset : 0;
	unsigned int reg[] = { 0x3000C,0x30018,0x30024,0x30030,0x3003c,0x30048,0x30054,0x30060,0x3006C,0x30078,0x30084,0x30090};//寄存器flag

	writel(reg[chan] + 4, dstwidth);	//脉宽
	writel(reg[chan] + 8, dstOffset);		//偏移
	writel(0x00030000,0xffffffff);			//触发
	return 0;
}

int CCpldV1::ReadTimeStamp(TSyncuStamp* tv)
{
	std::lock_guard<std::mutex> lock(m_mutex);
	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}
	
	//填充请求结构
	TCpldV1TimeStampReq stuReq;
	stuReq.stuHead.dwHead = htonl(CPLD_MSG_HEAD_V1);
	stuReq.stuHead.bySeq = 0;
	stuReq.stuHead.byAction = 1;
	stuReq.stuHead.wType = htons(1);
	stuReq.stuHead.wSize = htons(0);
	stuReq.stuTail.byCheck = calCheck((unsigned char*)&stuReq, sizeof(stuReq) - sizeof(TCpldV1MsgTail));
	stuReq.stuTail.dwTail = htonl(CPLD_MSG_TAIL_V1);

	//请求
	char szBuf[256];
	int nDataLen = 0;
	int ret = requestCpld(&stuReq, sizeof(stuReq), szBuf,sizeof(szBuf), nDataLen);

	//处理请求结果
	if (ret < 0)
	{
		printf("requestCpld failed\n");
		return -1;
	}

	if (nDataLen == sizeof(TCpldV1ErrorMsg))
	{
		TCpldV1ErrorMsg* pTemp = (TCpldV1ErrorMsg*)szBuf;
		printf("read time stamp failed,cpld errcode=%d\n", pTemp->byErrCode);
		return -1;
	}

	if (nDataLen != sizeof(TCpldV1TimeStampRes))
	{
		printf("read time stamp failed,datalen %d invalid\n", nDataLen);
		return -1;
	}
	
	char szTempDate[128];
	struct tm tmcur;
	TCpldV1TimeStampRes* pStuStampRes = (TCpldV1TimeStampRes*)szBuf;
	
	snprintf(szTempDate, sizeof(szTempDate), "%s", pStuStampRes->szTime);
	tmcur.tm_year = 2000 + transAtoi(szTempDate, 2) - 1900;
	tmcur.tm_mon = transAtoi(szTempDate + 2, 2) - 1;
	tmcur.tm_mday = transAtoi(szTempDate + 4, 2);
	tmcur.tm_hour = transAtoi(szTempDate + 6, 2);
	tmcur.tm_min = transAtoi(szTempDate + 8, 2);
	if(m_bCompensation)
	{
		tmcur.tm_sec = transAtoi(szTempDate + 10, 2) + 1; //补偿1s，因为cpld是基于上一个gprmc的		
	}
	else
	{
		tmcur.tm_sec = transAtoi(szTempDate + 10, 2);
	}
	tmcur.tm_isdst = 0;
	tv->sec = mktime(&tmcur);
	tv->nan = 10 * transXtoi(szTempDate + 13, 8);
	return 0;
}

int CCpldV1::Readl(unsigned int dwReg,unsigned int *dwVal) 
{
	std::lock_guard<std::mutex> lock(m_mutex);
	return readl(dwReg,*dwVal);
}

int CCpldV1::Writel(unsigned int dwReg,unsigned int dwVal)
{
	std::lock_guard<std::mutex> lock(m_mutex);
	return writel(dwReg,dwVal);
}

unsigned char  CCpldV1::calCheck(unsigned char* szBuf,int len)
{
	unsigned byCheck = 0;
	for (int i = 0; i < len; i++)
	{
		byCheck = byCheck ^ szBuf[i];
	}
	return byCheck;
}

void  CCpldV1::resetSerial()
{
	printf(".......reset......\n");
	m_serial->Uart_close();
	m_serial->Uart_open(m_strDevName.c_str(), UART_BAUD_RATE, UART_DATA_BIT, UART_STOP_BIT, UART_PARITY, UART_FLOW_CTL);
}


int CCpldV1::ReadVersion(char* buf,int len)
{
	unsigned int dwVal = 0;
	readl(0x04, dwVal);

	//dwVal = htonl(dwVal); 
	int day = dwVal & 0xff;
	int month = (dwVal >> 8) & 0xff;
	//int year = ntohs(dwVal >> 16);
	int year = dwVal >> 16;
	readl(0x08, dwVal);

	int version = dwVal;
	snprintf(buf,len,"V%x build %x%02x%02x",version,year,month,day);
	//snprintf(buf,len,"cpld build date: %x-%x-%x,version:%x\n", year, month, day, version);
	printf("cpld build date: %x-%x-%x,version:%x,Compensation:%d\n", year, month, day, version,m_bCompensation);
	return 0;
}


void CCpldV1::showVersion()
{
	unsigned int dwVal = 0;
	readl(0x04, dwVal);

	//dwVal = htonl(dwVal); 
	int day = dwVal & 0xff;
	int month = (dwVal >> 8) & 0xff;
	//int year = ntohs(dwVal >> 16);
	int year = dwVal >> 16;
	readl(0x08, dwVal);

	int version = dwVal;
	if(version >= 0 && version<21)
        {
		m_bCompensation = true;
        }
	else if(version >= 21)
	{
		m_bCompensation = false;
	}
	printf("cpld build date: %x-%x-%x,version:%x\n", year, month, day, version);
}


int  CCpldV1::writel(unsigned int dwReg, unsigned dwVal)
{
	//填充请求结构
	#pragma pack(1)
	struct
	{
		TCpldV1MsgHead	stuHead;
		unsigned int    dwReg;
		unsigned int    dwVal;
		TCpldV1MsgTail	stuTail;
	}stuReq;
	#pragma pop()

	stuReq.stuHead.dwHead = htonl(CPLD_MSG_HEAD_V1);
	stuReq.stuHead.bySeq = 0;
	stuReq.stuHead.byAction = 0;
	stuReq.stuHead.wType = htons(0);
	stuReq.stuHead.wSize = htons(8);
	stuReq.dwReg = htonl(dwReg);
	stuReq.dwVal = htonl(dwVal);
	stuReq.stuTail.byCheck = calCheck((unsigned char*)&stuReq, sizeof(stuReq) - sizeof(TCpldV1MsgTail));
	stuReq.stuTail.dwTail = htonl(CPLD_MSG_TAIL_V1);

	int nDataLen = 0;
	char szBuf[512];
	int ret = requestCpld(&stuReq, sizeof(stuReq), szBuf, sizeof(szBuf), nDataLen);

	//处理请求结果
	if (ret < 0)
	{
		printf("requestCpld failed\n");
		return -1;
	}

	
	if(nDataLen == sizeof(stuReq))
	{	
		   unsigned int  *pData = (unsigned int *)(szBuf+sizeof(TCpldV1MsgHead));
		   unsigned int dwRetReg =*pData++;
		   unsigned int dwRetVal =  *pData;
			if(stuReq.dwReg == dwRetReg && stuReq.dwVal == dwRetVal)
			{
				return 0;
			}
			printf("writel failed,reg=0x%x,val=0x%x\n",ntohl(dwRetReg),ntohl(dwRetVal));
			return -1;
	}
	else
	{
			if (nDataLen == sizeof(TCpldV1ErrorMsg))
			{
				printf("cpld reg = %x,cpld errcode=%d\n", dwReg, szBuf[sizeof(TCpldV1MsgHead)]);
				return -1;
			}
	}
	printf("unkown error\n");
	return -1;
}

int  CCpldV1::readl(unsigned int dwReg, unsigned int& dwVal)
{
	//填充请求结构
	#pragma pack(1)
	struct
	{
		TCpldV1MsgHead	stuHead;
		unsigned int    dwReg;
		TCpldV1MsgTail	stuTail;
	}stuReq;

	 struct
        {
                TCpldV1MsgHead  stuHead;
                unsigned int    dwVal;
                TCpldV1MsgTail  stuTail;
        }stuRes;
	#pragma pop()	
	
	stuReq.stuHead.dwHead = htonl(CPLD_MSG_HEAD_V1);
	stuReq.stuHead.bySeq = 0;
	stuReq.stuHead.byAction = 1;
	stuReq.stuHead.wType = htons(0);
	stuReq.stuHead.wSize = htons(4);
	stuReq.dwReg = htonl(dwReg);
	stuReq.stuTail.byCheck = calCheck((unsigned char*)&stuReq, sizeof(stuReq) - sizeof(TCpldV1MsgTail));
	stuReq.stuTail.dwTail = htonl(CPLD_MSG_TAIL_V1);

	int nDataLen = 0;
	char szBuf[512];
	int ret = requestCpld(&stuReq, sizeof(stuReq), szBuf,sizeof(szBuf), nDataLen);

	//处理请求结果
	if (ret < 0)
	{
		printf("requestCpld failed\n");
		return -1;
	}

	if(nDataLen == sizeof(stuRes))
	{
		memcpy(&stuRes,szBuf,sizeof(stuRes));	
		dwVal = ntohl(stuRes.dwVal);
		return 0;
	}
	else
	{
		if (nDataLen == sizeof(TCpldV1ErrorMsg))
       		{
                	printf("requestCpld failed,cpld reg = %x,cpld errcode=%d\n",dwReg,szBuf[sizeof(TCpldV1MsgHead)]);
                	return -1;
       		}
	}
	printf("unkown error\n");
	return -1;
}


int CCpldV1::requestCpld(void* pData, int nDataLen, void* pBuf, int nBufLen,int &nRealLen)
{
	do 
	{
		nRealLen = 0;
		if (m_serial->Uart_send((const char*)pData, nDataLen) != nDataLen)
		{
			printf("Uart_send failed\n");
			break;
		}

		//读取头
		if (m_serial->Uart_readn((char*)pBuf, sizeof(TCpldV1MsgHead), 100) != sizeof(TCpldV1MsgHead))
		{
			printf("Uart_readn failed\n");
			break;
		}

		TCpldV1MsgHead* head = (TCpldV1MsgHead*)pBuf;
		int left = ntohs(head->wSize) + 5; //tail 5
		if (left > nBufLen - sizeof(TCpldV1MsgHead))
		{
			printf("there is no space,left=%d,buf=%d\n", left, nBufLen - (int)sizeof(TCpldV1MsgHead));
			break;
		}

		if (m_serial->Uart_readn((char*)pBuf + sizeof(TCpldV1MsgHead), left, 100) != left)
		{
			printf("Uart_readn failed\n");
			return -1;
		}

		nRealLen = left + sizeof(TCpldV1MsgHead);
		return 0;

	} while (0);
	
	resetSerial();
	return 0;
}

int  CCpldV1::setInitTime()
{
	char szTime[128] = {0};
	time_t rawtime;
	struct tm timeinfo;
	timeval tv;
	gettimeofday(&tv,NULL);
	time ( &rawtime );
	localtime_r( &rawtime,&timeinfo);
	int year,month,day,hour,min,sec;
	year = 1900+timeinfo.tm_year-2000;
	month = 1+timeinfo.tm_mon;
	day = timeinfo.tm_mday;
	hour = timeinfo.tm_hour;
	min = timeinfo.tm_min;
	sec = timeinfo.tm_sec;
	snprintf(szTime,sizeof(szTime),"%02d%02d%02d%02d%02d%02d.%08ld",day,month,year,hour,min,sec,tv.tv_usec);
	TCpldV1SetInitTimeReq stuReq;

	stuReq.stuHead.dwHead = htonl(CPLD_MSG_HEAD_V1);
	stuReq.stuHead.bySeq = 0;
	stuReq.stuHead.byAction = 0;
	stuReq.stuHead.wType = htons(1);
	stuReq.stuHead.wSize = htons(21);
	memcpy(stuReq.szTime,szTime,sizeof(stuReq.szTime));
	stuReq.stuTail.byCheck = calCheck((unsigned char*)&stuReq, sizeof(stuReq) - sizeof(TCpldV1MsgTail));
	stuReq.stuTail.dwTail = htonl(CPLD_MSG_TAIL_V1);

	char szRevBuf[64];
	int nDataLen = 0;
	requestCpld(&stuReq,sizeof(stuReq),szRevBuf,sizeof(szRevBuf),nDataLen);
	if(nDataLen != sizeof(TCpldV1ErrorMsg))
	{
		printf("requestCpld failed\n");
		return -1;
	}
	TCpldV1ErrorMsg *pRes = (TCpldV1ErrorMsg *)szRevBuf;
	if(pRes->byErrCode != 0)
	{
		printf("requestCpld failed\n");
		return -1;
	}
	return 0;
}

int CCpldV1 ::SetInputSerialParam(int channel,const char* level ,int baudRate)
{
	if(m_bSetInput == false)
	{
		return -1;
	}
	do
	{
		if(strncmp(level,"232",3) == 0)
		{
			writel(0x00020008, 0);
		}
		else if(strncmp(level,"485",3) == 0)
		{
			writel(0x00020008, 1);
		}
		else
		{
			printf("SetInput failed\n");
			return -1;
		}
		
		if(baudRate == 9600)
		{
			writel(0x00020030, 1);
		}
		else if(baudRate == 115200)
		{
			writel(0x00020030, 0);
		}

	}while (0);

	return 0;
}

int CCpldV1 ::SetOutputSerialParam(int channel,const char* level ,int baudRate)
{
	do
	{
		if(baudRate == 9600)
		{
			writel(0x00020034, 0);
		}
		else if(baudRate == 115200)
		{
			writel(0x00020034, 1);
		}
		else
		{
			printf("SetOutput failed\n");
			return -1;
		}
		
	} while (0);
	
	return 0;
}
