#include <stdlib.h>
#include "cpld_base.h"


CCpldBase::CCpldBase()
{
	m_nGpsMode = 0;
	m_serial = NULL;

}

CCpldBase::~CCpldBase()
{

}

int CCpldBase::Readl(unsigned int dwReg,unsigned int *dwVal) 
{
	printf("not support\n");
	return -1;
}

int CCpldBase::Writel(unsigned int dwReg,unsigned int dwVal)
{
	printf("not support\n");
	return -1;
}

int	CCpldBase::transAtoi(const char* str, int len)
{
	char szBuf[64];
	memset(szBuf, 0, sizeof(szBuf));
	strncpy(szBuf, str, len);
	return atoi(szBuf);
}

int	CCpldBase::transXtoi(const char* str, int len)
{
	char szBuf[64];
	memset(szBuf, 0, sizeof(szBuf));
	strncpy(szBuf, str, len);
	return strtol(szBuf, NULL, 16);
}