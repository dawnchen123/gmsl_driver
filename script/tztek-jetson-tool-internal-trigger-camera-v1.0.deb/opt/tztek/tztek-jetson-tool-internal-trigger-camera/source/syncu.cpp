/*==============================================================================
功能 		:	同步触发通信库源文件
版权        :  <Copyright(C) 2020-2025 Suzhou Tztek Technology Co., Ltd. All rights reserved.>
-------------------------------------------------------------------------------
修改记录    :
日  期         版本          修改人						修改记录
2020/10/10       1.0         zhl						创建
==============================================================================*/
#include "syncu.h"
#include "cpld_base.h"
#include "cpld_v0.h"
#include "cpld_v1.h"
#include "cpld_v0.h"
#include "cpld_v1.h"
#include  <iostream>
#include <memory>
#include <mutex>

using namespace std;
std::mutex	 g_mutexCpld;

SYNCU_API  int CALLBACK SYNCU_Init()
{
	return 0;
}

SYNCU_API  int CALLBACK SYNCU_Release()
{
	return 0;
}

SYNCU_API void*  CALLBACK SYNCU_CreateHandle(int mode,int version,const char *devname)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	CCpldBase* pCpld = NULL;
	switch (version)
	{
	case SYNCU_VERSION_V0:
		pCpld = new CCpldV0;
		break;
	case SYNCU_VERSION_V1:
		pCpld = new CCpldV1;
		break;
	default:
		printf("version is not support\n");
		break;
	}
	
	if (pCpld)
	{
		pCpld->Init(mode,devname);
	}

	return pCpld;
}

SYNCU_API int CALLBACK SYNCU_DestroyHandle(void* handle)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	CCpldBase* pBase = (CCpldBase*)handle;

	if(pBase)
	{
		pBase->DisableTrig();
		pBase->Release();
		delete pBase;
	}
	return 0;
}

SYNCU_API int CALLBACK SYNCU_DisableTrig(void* handle)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;

	if(pCpld != NULL)
	{
			nRet = pCpld->DisableTrig();
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_EnableTrig(void* handle)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;

	if(pCpld != NULL)
	{
		nRet = pCpld->EnableTrig();
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_SetTimeMode(void* handle, int chan, int hz, double width,int offset)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->SetTimeMode(chan,hz,width, offset);
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_SetManualMode(void* handle, int chan, double width, int offset)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->SetManualMode(chan, width, offset);
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_DoTrig(void* handle, int chan, double width,int offset)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->DoTrig(chan, width, offset);
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_ReadTimeStamp(void* handle, TSyncuStamp* tv)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->ReadTimeStamp(tv);
	}
	return nRet;
}

SYNCU_API int  CALLBACK  SYNCU_ReadVersion(void* handle,char *buf,int len)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->ReadVersion(buf,len);
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_Readl(void* handle,unsigned int dwReg,unsigned int *dwVal)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->Readl(dwReg,dwVal);
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_Writel(void* handle,unsigned int dwReg,unsigned int dwVal)
{
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->Writel(dwReg,dwVal);
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_SetInputSerialParam(void* handle , int channel,const char* level ,int baudRate)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->SetInputSerialParam(0,level,baudRate);
	}
	return nRet;
}

SYNCU_API int CALLBACK SYNCU_SetOutputSerialParam(void* handle, int channel,const char* level,int baudRate)
{
	std::unique_lock<std::mutex> lock(g_mutexCpld);
	int nRet = -1;
	CCpldBase* pCpld = (CCpldBase*)handle;
	if(pCpld != NULL)
	{
		nRet = pCpld->SetOutputSerialParam(0,"",baudRate);
	}
	return nRet;
}
