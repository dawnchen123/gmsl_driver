#include "cpld_v0.h"


CCpldV0::CCpldV0()
{
     m_serial =NULL;
}

CCpldV0::~CCpldV0()
{
	if (m_serial)
	{
		delete m_serial;
		m_serial = NULL;
	}
}

int	 CCpldV0 ::Init(int mode,const char *devname)
{
	int retval = -1;
	do
	{
		if (m_serial)
		{
			printf("alread inited\n");
			break;
		}
		m_serial = new CSerial;
		if (m_serial == NULL)
		{
            printf("new Serial failed,errno %d\n", errno);
			break;
		}

		if (m_serial->Uart_open(devname, UART_BAUD_RATE, UART_DATA_BIT, UART_STOP_BIT, UART_PARITY, UART_FLOW_CTL) < 0)
		{
            printf("uart_open %s failed,errno %d\n", devname, errno);
			break;
		}

		m_nGpsMode = mode;
		m_strDevName = devname;

		char ver[64];
		char seq[64];
		memset(ver, 0, sizeof(ver));
		memset(seq, 0, sizeof(seq));
		cpld_read(0x00, ver, sizeof(ver));
		cpld_read(0x04, seq, sizeof(seq));
        printf("cpld version:%s,seq:%s\n", ver, seq);
		retval = 0;

	} while (0);

	if (retval != 0)
	{
		if(m_serial)
		{
			delete m_serial;
			m_serial = NULL;
		}
	}
	return retval;
}

int CCpldV0 ::ReadVersion(char* buf,int len)
{
	return -1;
}

 int CCpldV0 ::Release()
{
	 if (m_serial)
	 {
		 delete m_serial;
		 m_serial = NULL;
	 }
     return 0;
}

int	 CCpldV0 ::EnableTrig()
{
	std::lock_guard<std::mutex> lock(m_mutex);
	unsigned int reg[] = { 0x1c,0x30,0x44,0x58,0x6c,0x80,0x94,0xa8 };

	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}
	return cpld_writel(reg[0], 1);
}

 int CCpldV0 ::DisableTrig()
{
	std::lock_guard<std::mutex> lock(m_mutex);
	 unsigned int reg[] = { 0x1c,0x30,0x44,0x58,0x6c,0x80,0x94,0xa8 };

	 if (m_serial == NULL)
	 {
         printf("m_serial is NULL\n");
		 return -1;
	 }
	 return cpld_writel(reg[0], 0);
}

int	CCpldV0::DoTrig(int chan,double width,int offset)
{
	std::lock_guard<std::mutex> lock(m_mutex);
	unsigned int reg[] = { 0x1c,0x30,0x44,0x58,0x6c,0x80,0x94,0xa8 };
	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}
	if (chan >= MAX_TRIG_CHAN_NUM)
	{
		printf("chan %d is invalid\n", chan);
		return -1;
	}

	unsigned int dstwidth = 1e8 * (width / 1e9);
	unsigned int dstOffset = offset ? 1e8 / (1e6 * offset) : 0;

	cpld_writel(reg[chan], 0);
	cpld_writel(0x10, 2);
	cpld_writel(0x18, 2);
	cpld_writel(reg[chan] + 8, dstwidth);
	cpld_writel(reg[chan] + 12, dstOffset);
	cpld_writel(reg[chan], 1);
	return 0;
}

int CCpldV0::SetTimeMode(int chan,int fps,double width,int offset)
{
	std::lock_guard<std::mutex> lock(m_mutex);
	unsigned int reg[] = { 0x1c,0x30,0x44,0x58,0x6c,0x80,0x94,0xa8 };
	unsigned int dstfreq;
	unsigned int dstwidth;
	unsigned int dstOffset;

	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}
	if (chan >= MAX_TRIG_CHAN_NUM)
	{
		printf("chan %d is invalid\n", chan);
		return -1;
	}

	if (fps < 1)
	{
		fps = 10;
	}
	dstfreq = 1e8 / fps;
	dstwidth = 0x186a0;
	dstOffset = offset ? 1e8 / (1e6 * offset) : 0;

	cpld_writel(reg[chan], 0);
	cpld_writel(0x10, 1);
	cpld_writel(0x18, 3);
	cpld_writel(reg[chan] + 4, dstfreq);
	cpld_writel(reg[chan] + 8, dstwidth);
	cpld_writel(reg[chan] + 12, dstOffset);
	return 0;
}

int CCpldV0::SetManualMode(int chan, double width, int offset)
{
	std::lock_guard<std::mutex> lock(m_mutex);
	unsigned int reg[] = { 0x1c,0x30,0x44,0x58,0x6c,0x80,0x94,0xa8 };
	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}
	if (chan >= MAX_TRIG_CHAN_NUM)
	{
		printf("chan %d is invalid\n", chan);
		return -1;
	}

	unsigned int dstwidth = 1e8 * (width / 1e9);

	cpld_writel(reg[chan], 0);
	cpld_writel(0x10, 2);
	cpld_writel(0x18, 2);
	cpld_writel(reg[chan] + 8, dstwidth);
	cpld_writel(reg[chan] + 12, 0);
	return 0;
}

int CCpldV0 ::ReadTimeStamp(TSyncuStamp *tv)
{
	std::lock_guard<std::mutex> lock(m_mutex);
	if (m_serial == NULL)
	{
		printf("m_serial is NULL\n");
		return -1;
	}

	char szDate[128];
	struct tm tmcur;
	memset(szDate, 0, sizeof(szDate));
	if (cpld_read(0xbc, szDate, sizeof(szDate)) < 0)
	{
		printf("cpld_read is failed\n");
		return -1;
	}

    tmcur.tm_year = 2000+transAtoi(szDate,2)-1900;
	tmcur.tm_mon = transAtoi(szDate+2,2) - 1;
	tmcur.tm_mday = transAtoi(szDate+4,2) ;
	tmcur.tm_hour = transAtoi(szDate+6,2) ;
	tmcur.tm_min = transAtoi(szDate+8,2) ;
	tmcur.tm_sec = transAtoi(szDate+10,2)+1;  //����1s,��Ϊcpld�ǻ�����һ֡��gprmc
	tmcur.tm_isdst = 0;
	tv->sec = mktime(&tmcur);
	tv->nan = 10 * transXtoi(szDate + 12, 8);
	return 0;
}

 int CCpldV0::cpld_read(unsigned int reg,char *out,int outlen)
{
	 char szBuf[64];
	 int len = 0;

	 memset(szBuf, 0, sizeof(szBuf));
	 len = snprintf(szBuf, sizeof(szBuf), "r %02x%02x%02x%02x\n",
		 (reg >> 24) & 0xff, (reg >> 16) & 0xff, (reg >> 8) & 0xff, (reg & 0xff));
	 if ((int)m_serial->Uart_send(szBuf, len) != len)
	 {
		 printf("uart_send failed,content=%s\n", szBuf);
		 return -1;
	 }

	 memset(szBuf, 0, sizeof(szBuf));
	 len = m_serial->Uart_read_line(szBuf, sizeof(szBuf) - 1, CPLD_TIME_OUT);
	 if (len <= 0)
	 {
		 printf("uart_read_line failed,errno %d\n", errno);
		 m_serial->Uart_close();
		 m_serial->Uart_open(m_strDevName.c_str(), UART_BAUD_RATE, UART_DATA_BIT, UART_STOP_BIT, UART_PARITY, UART_FLOW_CTL);
		 return -1;
	 }
	 memset(out, 0, outlen);
	 strncpy(out, szBuf, len - 1);
	 return 0;
}

unsigned int CCpldV0::cpld_read(unsigned int reg)
{
	char szBuf[64];
	int len = 0;


	memset(szBuf, 0, sizeof(szBuf));
	len = snprintf(szBuf, sizeof(szBuf), "r %02x%02x%02x%02x\n",
		(reg >> 24) & 0xff, (reg >> 16) & 0xff, (reg >> 8) & 0xff, (reg & 0xff));
	if ((int)m_serial->Uart_send(szBuf, len) != len)
	{
		printf("uart_send failed,content=%s\n", szBuf);
		return -1;
	}


	memset(szBuf, 0, sizeof(szBuf));
	if (m_serial->Uart_read_line(szBuf, sizeof(szBuf) - 1, CPLD_TIME_OUT) <= 0)
	{
		printf("uart_read_line failed,errno %d\n", errno);
		m_serial->Uart_close();
		m_serial->Uart_open(m_strDevName.c_str(), UART_BAUD_RATE, UART_DATA_BIT, UART_STOP_BIT, UART_PARITY, UART_FLOW_CTL);
	}
	return strtol(szBuf, NULL, 16);
}

 int CCpldV0 ::cpld_writel(unsigned int reg,unsigned int value)
{
	 char szBuf[64];
	 int len = 0;

	 memset(szBuf, 0, sizeof(szBuf));
	 len = snprintf(szBuf, sizeof(szBuf), "w %02x%02x%02x%02x %02x%02x%02x%02x\n",
		 (reg >> 24) & 0xff, (reg >> 16) & 0xff, (reg >> 8) & 0xff, (reg & 0xff),
		 (value >> 24) & 0xff, (value >> 16) & 0xff, (value >> 8) & 0xff, (value & 0xff));
	 if ((int)m_serial->Uart_send(szBuf, len) != len)
	 {
		 printf("uart_send failed,content=%s\n", szBuf);
		 return -1;
	 }
	 return 0;
}

 int CCpldV0 ::cpld_writew(unsigned int reg,unsigned short value)
{
	 char szBuf[64];
	 int len = 0;

	 memset(szBuf, 0, sizeof(szBuf));
	 len = snprintf(szBuf, sizeof(szBuf), "w %02x%02x%02x%02x %02x%02x\n",
		 (reg >> 24) & 0xff, (reg >> 16) & 0xff, (reg >> 8) & 0xff, (reg & 0xff),
		 (value >> 8) & 0xff, (value & 0xff));
	 if ((int)m_serial->Uart_send(szBuf, len) != len)
	 {
		 printf("uart_send failed,content=%s\n", szBuf);
		 return -1;
	 }
	 return 0;
}

 int CCpldV0 ::cpld_writeb(unsigned int reg,unsigned char value)
{
	 char szBuf[64];
	 int len = 0;

	 memset(szBuf, 0, sizeof(szBuf));
	 len = snprintf(szBuf, sizeof(szBuf), "w %02x%02x%02x%02x %02x\n",
		 (reg >> 24) & 0xff, (reg >> 16) & 0xff, (reg >> 8) & 0xff, (reg & 0xff), value);
	 if ((int)m_serial->Uart_send(szBuf, len) != len)
	 {
		 printf("uart_send failed,content=%s\n", szBuf);
		 return -1;
	 }
	 return 0;
}


int CCpldV0 ::SetInputSerialParam(int channel,const char* level ,int baudRate)
{
	return 0;
}
int CCpldV0 ::SetOutputSerialParam(int channel,const char* level ,int baudRate)
{
	return 0;
}

