#include <stdio.h>
#include <unistd.h>
#include <iostream>
#include "syncu.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <thread>
#include <sys/time.h>
#include <time.h>
#include <iostream>
#include <string.h>
#include <poll.h>
#include <signal.h>
#include <queue>
#include <mqueue.h>
#include <semaphore.h>
#include <sys/prctl.h>
#include <assert.h>

sem_t g_semTrig;

void trig_handler(int sig)
{
        sem_post(&g_semTrig);
}

int initTrigInterrupt(const char *dev_name)
{
        int fd;
        int ret = 0;
        int oflags;
        do
        {
                if ((fd = open(dev_name, O_RDONLY)) < 0)
                {
                        ret = -1;
                        std::cout << "open trig interrupt false..." << std::endl;
                        break;
                }
                else
                {
                        signal(SIGIO, trig_handler);
                        fcntl(fd, F_SETOWN, getpid());
                        oflags = fcntl(fd, F_GETFL);
                        fcntl(fd, F_SETFL, oflags | FASYNC);
                }

        } while (0);
        return ret;
}

int main(int argc,char *argv[])
{
        if(argc != 4)
        {
                printf("sudo %s <devname>  <fps>  <us>,eg sudo syncudemo /dev/ttyTHS4 10 1000 . if fps is zero,system stop trigger\n",argv[0]);
                return -1;
        }

        int nFps =  atoi(argv[2]);
        int nUs = 1000;
        if(argv[3] != NULL){
                nUs = atoi(argv[3]);
        }


        sem_init(&g_semTrig, 0, 0);

        //初始化
        SYNCU_Init();

        //创建句柄
        void *handle = SYNCU_CreateHandle(0, 1, argv[1]); ///dev/ttyTHS4
        assert(handle != nullptr);

        //先停止触发
        SYNCU_DisableTrig(handle);

        //停止直接退出
        if(nFps == 0)
        {
                printf("trigger is closed\n");
                return 0;
        }

        //打开中断
        initTrigInterrupt("/dev/camera_trigger");

        //读取版本
        char buf[64] = {0};
        SYNCU_ReadVersion(handle, buf, sizeof(buf));
        printf("cpld version is %s\n",buf);

        //设置定时处罚
        for (int i = 0; i < MAX_TRIG_CHAN_NUM; i++)
        {
                SYNCU_SetTimeMode(handle, i, nFps, nUs, 0);
        }

        //使能触发
        usleep(1000 * 1000);
        SYNCU_EnableTrig(handle);

        int fd = open("time_stamp.txt", O_RDWR | O_CREAT|O_TRUNC , 0666);
        assert(fd != -1);

        //读取触发时间戳
        while (1)
        {
                sem_wait(&g_semTrig);
                TSyncuStamp tv;
                if (SYNCU_ReadTimeStamp(handle, &tv) < 0)
                {
                        printf("read timestamp failed\n");
                }
                else
                {
                        printf("cpld:[%lld.%09lld]\n", tv.sec, tv.nan);
                        dprintf(fd, "%lld%09lld\n", tv.sec, tv.nan);
                }
        }

        //退出
        SYNCU_DestroyHandle(handle);
        SYNCU_Release();
        sem_close(&g_semTrig);
        close(fd);
        return 0;
}
